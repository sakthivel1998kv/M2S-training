from rest_framework import serializers
from card_api.models import card



class CardSerializer(serializers.ModelSerializer):
    class Meta:
        model = card
        fields = "__all__"
           