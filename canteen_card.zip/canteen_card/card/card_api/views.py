"""from urllib import request
from django.shortcuts import redirect, render
from card.card_api import serializers
from card_api.models import card
from card_api.models import cardForm


def card(request):
    if request.method =="POST":
        form=cardForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect("/show")
            except:
                pass
    else:
        form = cardForm()
    return render(request,{'form': form})


def show(request):
    card = card.objects.all()
    return render(request,{'card':card})

def edit(request,id):
    card = card.objects.get(id=id)
    return render(request,{'card':card})


def update(request,id):
    card = card.objects.get(id=id)
    form = cardForm(request.POST,instance = card) 
    if form.is_valid():
        form.save()
        return redirect("/show")
    return render(request,{'card':card})

def delete(request,id):
    card = card.objects.get(id=id)
    card.delete()
    return redirect("/show")  """         





from django.shortcuts import render
from rest_framework import generics
from card_api.models import card
from card_api.serializers import CardSerializer

class CardList(generics.ListCreateAPIView):
    queryset = card.objects.all()
    serializer_class = CardSerializer

class CardDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset =  card 
    serializers_class = CardSerializer  





