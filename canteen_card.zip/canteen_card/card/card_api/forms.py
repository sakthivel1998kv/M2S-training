from dataclasses import field
from pyexpat import model
from django import forms
from card_api.models import card



class card_apiForm(forms.ModelForm):
    class Meta:
        model=card
        fields='__all__'
    

    