from distutils.command.upload import *
from django.db import models


# Create your models here.

my_choices =(
    ('Paramilitary', 'Paramilitary'),
    ('State Govt', 'State Govt'),
    ('Central Govt', 'Central Govt'),
    ('Exmen Window', 'Exmen Window'),
    ('Others', 'Others')

)

my_choices2 =(
    ('Service', 'Service'),
    ('Retired', 'Retired')
    
)


  
class card(models.Model):
    image = models.ImageField(null=True, blank=True)
    first_name = models.CharField(max_length=100 )
    last_name = models.CharField(max_length=100 )
    applicant_type = models.CharField(max_length=100, choices=my_choices)
    offical_ststus = models.CharField(max_length=100, choices=my_choices2)
    rank_or_designation = models.CharField(max_length=150 )
    force_or_employeeid_or_exmenpensioner_no = models.CharField(max_length=150 )
    unit_or_place_of_work = models.CharField(max_length=150 )
    name_of_spouse = models.CharField(max_length=150 )
    residential_address = models.CharField(max_length=2500,default=0)
    pincode      = models.IntegerField(default=0)
    contact_no    = models.CharField(max_length=17, unique=True)
    date_of_birth = models.DateField(default=0) 

def __str__(self):
        return self.name
    








  
   